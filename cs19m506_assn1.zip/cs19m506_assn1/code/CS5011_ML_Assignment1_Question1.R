# installing caret library
install.packages('lifecycle', dependencies = TRUE)
install.packages('gower', dependencies = TRUE)
install.packages('caret', dependencies = TRUE)
library(caret)

# reading data file
dataset = readRDS("~/Personal/git/ML_Assignment1/Q1_data_01.Rda")

# list types for each attribute
sapply(dataset, class)

# printing data file on console
head(dataset)

# printing summary of data set
summary(dataset)

# correlation between predictors
cor(dataset$x1, dataset$x2)
cor(dataset$x1, dataset$x3)
cor(dataset$x1, dataset$x4)

cor(dataset$x2, dataset$x3)
cor(dataset$x2, dataset$x4)

cor(dataset$x3, dataset$x4)

# correlation between predictors and outcome
cor(dataset$x1, dataset$y)
cor(dataset$x2, dataset$y)
cor(dataset$x3, dataset$y)
cor(dataset$x4, dataset$y)

# scatterplot matrix.
plot(dataset)

# splitting the data into training and testing sets
set.seed(1234)
ind <- sample(2, nrow(dataset), replace=TRUE, prob=c(0.67, 0.33))

training_dataset = dataset[ind==1, 1:5]
test_dataset =  dataset[ind==2, 1:5]

nrow(dataset)
nrow(training_dataset)
nrow(test_dataset)

# creating linear model
linear_model = lm(y ~ ., data = training_dataset)
summary(linear_model)

# predicting data
model_predictions <- predict(linear_model, test_dataset)

# comparing actual test data with pridicted data
summary(test_dataset$y)
summary(model_predictions)

actuals_predictions = data.frame(cbind(actuals=test_dataset$y, predicteds=model_predictions))
correlation_accuracy <- cor(actuals_predictions)
head(correlation_accuracy)