# Q2_fun_01: 𝑦= 𝑒−5(𝑥−0.3)^2+0.5 𝑒−100(𝑥−0.5)^2+0.5 𝑒−100(𝑥−0.75)^2
# Q2_fun_02: 𝑦=2−3𝑥+10𝑥4−5𝑥9+6𝑥14

# functions defined in the question
func_01_y = function(x) exp(-5*(x-0.3)^2)+(0.5*exp(-100*(x-0.5)^2))+(0.5*exp(-100*(x-0.75)^2))
func_02_y = function(x) 2-3*x+10*x^4-5*x^9+6*x^14

# 2.1 - generating a sequnce and plotting for both functions
x = seq(0,1,0.0001)

plot(x, func_01_y(x), col="orange", main="Q2_fun_01", xlab="X", ylab="Y")
plot(x, func_02_y(x), col="green", main="Q2_fun_02", xlab="X", ylab="Y")

# 2.2 - adding normally distributed noise to the data points
random_x = sample(x, 100)
random_x

noise = rnorm(100,0,0.1)
noise

noisy_func_01_y = func_01_y(random_x) + noise
noisy_func_01_y

noisy_func_02_y = func_02_y(random_x) + noise
noisy_func_02_y

# 2.3, 2.4 - fitting polynomial of degree 𝑑 and computing the bias and variance for the models fitted

bias = function (predicted, actual){
    mean(predicted - actual)
}

model1_d_5 = lm(noisy_func_01_y ~ poly(random_x, 5))
summary(model1_d_5)

prediction1_d_5 = predict(model1_d_5)
bias1_d_5 = bias(prediction1_d_5, noisy_func_01_y)
variance1_d_5 = var(prediction1_d_5, noisy_func_01_y)

model1_d_13 = lm(noisy_func_01_y ~ poly(random_x, 13))
summary(model1_d_13)

prediction1_d_13 = predict(model1_d_13)
bias1_d_13 = bias(prediction1_d_13, noisy_func_01_y)
variance1_d_13 = var(prediction1_d_13, noisy_func_01_y)

model1_d_22 = lm(noisy_func_01_y ~ poly(random_x, 22))
summary(model1_d_22)

prediction1_d_22 = predict(model1_d_22)
bias1_d_22 = bias(prediction1_d_22, noisy_func_01_y)
variance1_d_22 = var(prediction1_d_22, noisy_func_01_y)

model2_d_5 = lm(noisy_func_02_y ~ poly(random_x, 5))
summary(model2_d_5)

prediction2_d_5 = predict(model2_d_5)
bias2_d_5 = bias(prediction2_d_5, noisy_func_02_y)
variance2_d_5 = var(prediction2_d_5, noisy_func_02_y)

model2_d_13 = lm(noisy_func_02_y ~ poly(random_x, 13))
summary(model2_d_13)

prediction2_d_13 = predict(model2_d_13)
bias2_d_13 = bias(prediction2_d_13, noisy_func_02_y)
variance2_d_13 = var(prediction2_d_13, noisy_func_02_y)

model2_d_22 = lm(noisy_func_02_y ~ poly(random_x, 22))
summary(model2_d_22)

prediction2_d_22 = predict(model2_d_22)
bias2_d_22 = bias(prediction2_d_22, noisy_func_02_y)
variance2_d_22 = var(prediction2_d_22, noisy_func_02_y)

bias = c(bias1_d_5,bias1_d_13,bias1_d_22,bias2_d_5,bias2_d_13,bias2_d_22)
variance = c(variance1_d_5,variance1_d_13,variance1_d_22,variance2_d_5,variance2_d_13,variance2_d_22)

# 2.5 - bias-variance plot
plot(bias, variance, col="orange", main="bias-variance", xlab="bias", ylab="variance")
